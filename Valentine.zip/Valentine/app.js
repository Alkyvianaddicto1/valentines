// Display a random message when the button is clicked
document.getElementById('showMessageBtn').addEventListener('click', function() {
  const messages = [
      "Love is in the air! 💖",
      "Your heart knows no bounds! 💕",
      "Together, you're unstoppable! 💫",
      "True love is forever! 🌹"
  ];

  const randomMessage = messages[Math.floor(Math.random() * messages.length)];
  document.getElementById('message').innerText = randomMessage;
});

// Redirect to trivia sections when buttons are clicked
document.getElementById('couplesTriviaBtn').addEventListener('click', function() {
  window.location.href = "couples_trivia.html";
});

document.getElementById('bestFriendsTriviaBtn').addEventListener('click', function() {
  window.location.href = "bestfriends_trivia.html";
});

document.getElementById('friendsTriviaBtn').addEventListener('click', function() {
  window.location.href = "friends_trivia.html";
});

// Form submission: Collect user's email and username
document.getElementById('userForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const email = document.getElementById('email').value;
  const username = document.getElementById('username').value;

  if (email && username) {
      alert(`Welcome, ${username}! You will receive results at ${email}.`);
      // Call backend API to save data and send emails
  } else {
      alert("Please enter both email and username.");
  }
});
