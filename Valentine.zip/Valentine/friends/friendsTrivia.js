// friendsTrivia.js
document.addEventListener("DOMContentLoaded", function() {
    const submitButton = document.getElementById('submitFriendsTrivia');
    submitButton.addEventListener('click', submitFriendsTrivia);
  
    function submitFriendsTrivia(event) {
      event.preventDefault();
  
      // Collect answers
      const answers = [
        document.getElementById('friendQ1').value,
        document.getElementById('friendQ2').value,
        document.getElementById('friendQ3').value
      ];
  
      // Validate answers
      if (answers.includes("")) {
        alert("Please answer all questions.");
        return;
      }
  
      // Collect user data and save answers
      const userData = {
        email: document.getElementById('userEmail').value,
        answers: answers
      };
  
      console.log("Friends Trivia Answers: ", userData);
  
      // Redirect or show confirmation
      alert("Your answers have been submitted. Please share the link with your friend.");
      
      // Generate a unique link for Partner 2 (mock implementation)
      const uniqueLink = generateUniqueLink();
      console.log("Link for Partner 2: ", uniqueLink);
    }
  
    // Generate a unique link for Partner 2
    function generateUniqueLink() {
      return `https://yourwebsite.com/trivia?token=${Math.random().toString(36).substr(2, 9)}`;
    }
  });
  