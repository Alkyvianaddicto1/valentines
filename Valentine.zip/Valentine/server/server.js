const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const mongoose = require('mongoose');
const TriviaAnswer = require('./models/TriviaAnswer');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

mongoose.connect('mongodb://localhost:27017/triviaDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// Nodemailer configuration
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'deofficialsklout254@gmail.com',
    pass: 'Skunkyclout254'
  }
});

// API Route to submit trivia answers
app.post('/submit-trivia', async (req, res) => {
  const { userEmail, partnerEmail, answers } = req.body;

  if (!userEmail || !partnerEmail || !answers) {
    return res.status(400).send('Missing required fields.');
  }

  const triviaAnswer = new TriviaAnswer({ userEmail, partnerEmail, answers });
  await triviaAnswer.save();

  // Send email to partner
  const mailOptions = {
    from: 'deofficialsklout254@gmail.com',
    to: partnerEmail,
    subject: 'Your Partner Finished Their Trivia!',
    text: `Your partner completed their trivia! Here are their answers:\n\n${JSON.stringify(answers)}`
  };

  transporter.sendMail(mailOptions, (err, info) => {
    if (err) {
      return res.status(500).send('Error sending email');
    }
    res.status(200).send('Trivia answers saved and email sent!');
  });
});

app.listen(3000, () => console.log('Server running on port 3000'));
