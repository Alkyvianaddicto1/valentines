// couplesTrivia.js
document.addEventListener("DOMContentLoaded", function() {
    const submitButton = document.getElementById('submitCouplesTrivia');
    submitButton.addEventListener('click', submitCouplesTrivia);
  
    function submitCouplesTrivia(event) {
      event.preventDefault();
  
      // Collect answers
      const answers = [
        document.getElementById('coupleQ1').value,
        document.getElementById('coupleQ2').value,
        document.getElementById('coupleQ3').value
      ];
  
      // Validate answers (you can extend this with more validations)
      if (answers.includes("")) {
        alert("Please answer all questions.");
        return;
      }
  
      // Create an object to hold user data and answers
      const userData = {
        email: document.getElementById('userEmail').value,
        answers: answers
      };
  
      // Save user data to a backend or local storage
      console.log("Couples Trivia Answers: ", userData);
  
      // Redirect to confirmation page or thank you page (if needed)
      alert("Your answers have been submitted. Please share the link with your partner.");
      
      // Here you could generate a unique link for Partner 2 (mock implementation)
      const uniqueLink = generateUniqueLink();
      console.log("Link for Partner 2: ", uniqueLink);
    }
  
    // Generate a unique link for Partner 2
    function generateUniqueLink() {
      return `https://yourwebsite.com/trivia?token=${Math.random().toString(36).substr(2, 9)}`;
    }
  });
  