// bestFriendsTrivia.js
document.addEventListener("DOMContentLoaded", function() {
    const submitButton = document.getElementById('submitBestFriendsTrivia');
    submitButton.addEventListener('click', submitBestFriendsTrivia);
  
    function submitBestFriendsTrivia(event) {
      event.preventDefault();
  
      // Collect answers
      const answers = [
        document.getElementById('bestFriendQ1').value,
        document.getElementById('bestFriendQ2').value,
        document.getElementById('bestFriendQ3').value
      ];
  
      // Validate answers
      if (answers.includes("")) {
        alert("Please answer all questions.");
        return;
      }
  
      // Collect user data and save answers
      const userData = {
        email: document.getElementById('userEmail').value,
        answers: answers
      };
  
      console.log("Best Friends Trivia Answers: ", userData);
  
      // Redirect or show confirmation
      alert("Your answers have been submitted. Please share the link with your best friend.");
      
      // Generate a unique link for Partner 2 (mock implementation)
      const uniqueLink = generateUniqueLink();
      console.log("Link for Partner 2: ", uniqueLink);
    }
  
    // Generate a unique link for Partner 2
    function generateUniqueLink() {
      return `https://yourwebsite.com/trivia?token=${Math.random().toString(36).substr(2, 9)}`;
    }
  });
  