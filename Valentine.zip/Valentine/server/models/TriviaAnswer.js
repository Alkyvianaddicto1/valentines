const mongoose = require('mongoose');

const triviaAnswerSchema = new mongoose.Schema({
  userEmail: String,
  partnerEmail: String,
  answers: Array,
  dateSubmitted: { type: Date, default: Date.now }
});

const TriviaAnswer = mongoose.model('TriviaAnswer', triviaAnswerSchema);

module.exports = TriviaAnswer;
